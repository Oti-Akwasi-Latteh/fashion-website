/* let cartItems = LoadFromSessionStorage("cartItems") || [];
    let cartCount = cartItems.length;

    function SaveToSessionStorage(key, value) {
      sessionStorage.setItem(key, JSON.stringify(value));
    }

    function LoadFromSessionStorage(key) {
      const data = sessionStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    }

    function updateCartCount() {
      const cartCounter = document.getElementById('cart-count');
      if (cartCounter) {
        cartCounter.innerText = cartCount;
      }
    }

    function renderCart() {
      const cartContainer = document.getElementById('cart-items');
      cartContainer.innerHTML = "";

      if (cartItems.length === 0) {
        cartContainer.innerText = "YOUR CART IS EMPTY";
        return;
      }

      cartItems.forEach(item => {
        const div = document.createElement('div');
        div.classList.add("cart-item");
        div.innerHTML = `
          <img src="${item.image}" width="80" height="80" alt="${item.name}">
          <div>
            <h3>${item.name}</h3>
            <p>${item.price}</p>
          </div>
        `;
        cartContainer.appendChild(div);
      });
    }

    function clearCart() {
      cartItems = [];
      cartCount = 0;
      sessionStorage.removeItem("cartItems");
      updateCartCount();
      renderCart();
    }

    updateCartCount();
    renderCart();*/


// Existing cart data handling
let cartItems = LoadFromSessionStorage("cartItems") || [];
let cartCount = cartItems.length;

function SaveToSessionStorage(key, value) {
  sessionStorage.setItem(key, JSON.stringify(value));
}

function LoadFromSessionStorage(key) {
  const data = sessionStorage.getItem(key);
  return data ? JSON.parse(data) : null;
}

function updateCartCount() {
  const cartCounter = document.getElementById('cart-count');
  if (cartCounter) {
    cartCounter.innerText = cartCount;
  }
}

function renderCart() {
  const cartContainer = document.getElementById('cart-items');
  cartContainer.innerHTML = "";

  if (cartItems.length === 0) {
    cartContainer.innerText = "Your cart is empty.";
    cartContainer.style.display = "flex";
    cartContainer.style.justifyContent = "center";
    cartContainer.style.alignItems = "center";
    cartContainer.style.minHeight = "200px";
    return;
  }

  cartItems.forEach((item, index) => {
    const div = document.createElement('div');
    div.classList.add("cart-item");
    div.innerHTML = `
      <img src="${item.image}" width="80" height="80" alt="${item.name}">
      <div>
        <h3>${item.name}</h3>
        <p>${item.price}</p>
      </div>
      <button class="remove-btn" data-index="${index}">✖</button>
    `;
    cartContainer.appendChild(div);
  });

  document.querySelectorAll(".remove-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const index = e.target.getAttribute("data-index");
      removeCartItem(index);
    });
  });
}

function removeCartItem(index) {
  cartItems.splice(index, 1);
  cartCount = cartItems.length;
  SaveToSessionStorage("cartItems", cartItems);
  updateCartCount();
  renderCart();
}

// 🔹 Function to save cart to MongoDB
async function addToCart(item) {
  // Local cart
  cartItems.push(item);
  cartCount = cartItems.length;
  SaveToSessionStorage("cartItems", cartItems);
  updateCartCount();
  renderCart();

  // Send to backend MongoDB
  try {
    const token = sessionStorage.getItem("token");
    const userId = sessionStorage.getItem("userId");

    const res = await fetch("http://localhost:3000/api/carts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "token": `Bearer ${token}`
      },
      body: JSON.stringify({
        userId: userId,
        products: [
          {
            productId: item.id,
            quantity: item.quantity || 1
          }
        ]
      })
    });

    if (!res.ok) {
      const err = await res.json();
      console.error("Failed to save cart:", err);
    } else {
      const data = await res.json();
      console.log("Cart synced with MongoDB:", data);
    }
  } catch (err) {
    console.error("Error saving cart:", err);
  }
}

// 🔹 Attach event listeners to cart icons
document.querySelectorAll(".cart-icon").forEach(icon => {
  icon.addEventListener("click", () => {
    const product = {
      id: icon.getAttribute("data-id"),
      name: icon.getAttribute("data-name"),
      price: icon.getAttribute("data-price"),
      image: icon.getAttribute("data-image"),
      quantity: 1
    };
    addToCart(product);
  });
});

// Initial render
updateCartCount();
renderCart();
