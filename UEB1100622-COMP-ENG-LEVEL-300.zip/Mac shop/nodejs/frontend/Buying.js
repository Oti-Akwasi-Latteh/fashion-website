const searchInput = document.getElementById('search-input');

  searchInput.addEventListener('input', function () {
    const query = this.value.toLowerCase().trim();

    const allProducts = document.querySelectorAll('.product-card, .card-2');

    allProducts.forEach(product => {
      const name = product.getAttribute('data-name').toLowerCase();
      if (name.includes(query)) {
        product.style.display = 'block';
      } else {
        product.style.display = 'none';
      }
    });
  });


