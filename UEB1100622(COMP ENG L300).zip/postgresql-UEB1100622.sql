create database MyDb;

create table students (
student_id int primary key,
first_name varchar(50),
last_name varchar(50),
department varchar(50),
Email varchar(100)

);

insert into students
value (1, 'kwame', 'Addo','computer engineering', 'kwameaddo@gmail.com'),
(2, 'jenni', 'blinks','information technilogy', 'jenniblinks@gmail.com'),
(3, 'john', 'carter','school of science','carterjohn@gmail.com');

alter table students 
drop column Email; 


select * from students 