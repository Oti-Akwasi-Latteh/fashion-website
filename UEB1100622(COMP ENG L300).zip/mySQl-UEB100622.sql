create database myfirstdb;

create table employees( 
customer_id int primary key,
first_name varchar(100),
last_nmae varchar(100),
Email varchar(100),
hired_date date
);

insert into employees 
value (1,"Jenny", "Blinks", "jennyblinks@gmail.com", "2023-01-05"),
	(2,"Patrick", "star", "partrickstar@gmail.com", "2020-05-01"),
    (3,"Sandy", "cheeks", "cheeksandy50@gmail.com", "2022-03-01"),
    (4,"Rich", "Spark", "richsparj@gmail.com", "2024-08-02"),
    (5,"Mac", "Lyphae", "maclyphae@gmail.com", "2022-01-01");
    
    alter table employees
    modify hired_date date after 
    Email;

select * from employees

