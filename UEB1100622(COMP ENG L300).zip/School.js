db = db.getSiblingDB("School");

db.createCollection("students");

db.students.insertMany([{_id:1, first_name:"Patrick", last_name:"Cheeks", age:22, gpa:3.0},

    {_id:2, first_name:"Charles", last_name:"Stars", age:25, gpa:2.8},

    {_id:3, first_name:"Alice", last_name:"Banks", age:20, gpa:3.55},

    {_id:4, first_name:"Bob", last_name:"Tee", age:28, gpa:2.55}
])

db.students.updateOne(
    {_id:1},
    {$set:{gpa:4.0}}
)


db.students.deleteOne({_id:4})


